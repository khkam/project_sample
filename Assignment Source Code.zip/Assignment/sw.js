/*
Copyright 2018 Google Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

const cacheName = 'cache-v1';
const precacheResources = [
  './index.html',
  './aboutus.html',
  './car_rental.html',
  './4wd.html',
  './e_sedan.html',
  './minicar.html',
  './mpv.html',
  './sedan.html',
  './booking.html',
  './subscribe.html',
  './suv.html',
  './contact.html',
  './js/main.js',
  './js/scripts.js',
  './css/home.css',
  './css/aboutus.css',
  './css/subscribe.css',
  './css/styles.css',
  './image/header.jpg',
  './image/close-icon.svg',
  './image/logo.svg',
  './image/map-image.png',
  './image/booking.jpg',
  './image/car_rental.jpg',
  './image/about/1.jpg',
  './image/about/2.jpg',
  './image/about/3.jpg',
  './image/about/4.jpg',
  './image/portfolio/1.jpg',
  './image/portfolio/2.jpg',
  './image/portfolio/3.jpg',
  './image/portfolio/3a.jpg',
  './image/portfolio/4.jpg',
  './image/portfolio/5.jpg',
  './image/portfolio/6.jpg',
  './image/team/1.jpg',
  './image/team/2.jpg',
  './image/team/3.jpg',
  './image/team/4.jpg',
  './image/cars/car1.jpg',
  './image/cars/car2.jpg',
  './image/cars/car3.jpg',
  './image/cars/car4.jpg',
  './image/cars/car5.jpg',
  './image/cars/car6.jpg',
  './image/cars/car7.jpg',
  './image/cars/car8.jpg',
  './image/cars/car9.jpg',
  './image/cars/car10.jpg',
  './image/cars/car11.jpg',
  './image/cars/car12.jpg',
  './image/cars/car13.jpg',
  './image/cars/car14.jpg',
  './image/cars/car15.jpg',
  './image/cars/car16.jpg',
  './image/cars/car17.jpg',
  './image/cars/car18.jpg',
  './image/cars/car19.jpg',
  './image/cars/car20.jpg',
  './image/cars/car21.jpg',
  './image/cars/car22.jpg',
  './image/cars/car23.jpg',
  './image/cars/car24.jpg',
  './image/cars/car25.jpg',
  './image/cars/car26.jpg',
  './image/cars/car27.jpg',
  './image/cars/car28.jpg',
  './image/cars/car29.jpg',
  './image/cars/car30.jpg',
  './image/cars/car31.jpg',
  './image/cars/car32.jpg',
  './image/cars/car33.jpg',
  './image/cars/car34.jpg',
  './image/cars/car35.jpg',
  './image/cars/car36.jpg',
  './image/cars/car37.jpg',
  './image/cars/car38.jpg',
  './image/cars/car39.jpg'
];

self.addEventListener('install', event => {
  console.log('Service worker install event!');
  event.waitUntil(
    caches.open(cacheName)
      .then(cache => {
        return cache.addAll(precacheResources);
      })
  );
});

self.addEventListener('activate', event => {
  console.log('Service worker activate event!');
});

self.addEventListener('fetch', event => {
  console.log('Fetch intercepted for:', event.request.url);
  event.respondWith(caches.match(event.request)
    .then(cachedResponse => {
        if (cachedResponse) {
          return cachedResponse;
        }
        return fetch(event.request);
      })
    );
});
